<?php
date_default_timezone_set('Asia/Jakarta');
$jamasuk = date('l, d-m-Y h:i:s');
$yearNow = date('Y');

$title = 'PUBG MOBILE: Stygian Liege X-Suit';
$description = 'Collect your special rewards in this Stygian Liege X-Suit event. This opportunity is limited and without the need for topup. Collect your rewards now!';
$copyright = 'PUBG MOBILE';
$theme = '#000';
$image = 'https://www.pubgmobile.com/images/event/stygianliege_suit/share2/en.jpg';
$icon = 'https://www.pubgmobile.com/common/images/icon_logo.jpg';
?>